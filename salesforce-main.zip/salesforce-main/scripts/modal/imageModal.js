document.addEventListener("DOMContentLoaded", function () {
  const modal = document.getElementById("myModal");
  const imgContainers = document.querySelectorAll(".img-wrapper");
  const modalImg = document.getElementById("img01");

  imgContainers.forEach((imgContainer) => {
    imgContainer.addEventListener("click", () => {
      modal.style.display = "block";
      document.body.style.overflow = "hidden";
      const img = imgContainer.querySelector("img");
      modalImg.src = img.src;
    });
  });

  const span = document.querySelector(".close");

  if (span) {
    span.onclick = () => {
      modal.style.display = "none";
      document.body.style.overflow = "";
    };
  }

  window.onclick = (event) => {
    if (event.target == modal) {
      modal.style.display = "none";
      document.body.style.overflow = "";
    }
  };
});
