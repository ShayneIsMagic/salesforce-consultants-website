const hamburgerWrapper = document.querySelector(".hamburger-wrapper");
const dropdownIcon = document.querySelector(".dropdown-icon");

hamburgerWrapper.addEventListener("click", () => {
  hamburgerWrapper.classList.toggle("open");
  if (hamburgerWrapper.classList.contains("open")) {
    dropdownIcon.classList.replace("fa-bars", "fa-times");
  } else {
    dropdownIcon.classList.replace("fa-times", "fa-bars");
  }
});
