// TODO: When we are in production we will introduce reCAPTCHA. We can't implememnt it now since we don't have it connected to the devpipeline.com domain

function sendEmail(event) {
  try {
    event.preventDefault();

    const formData = new FormData(event.target);

    fetch("/send-email", { method: "POST", body: formData })
      .then((res) => res.json())
      .finally(() => {
        event.target.reset();
      });
  } catch (error) {
    console.log("Error: ", error);
  }
}
