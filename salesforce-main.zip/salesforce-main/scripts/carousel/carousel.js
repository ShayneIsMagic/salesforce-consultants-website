document.addEventListener("DOMContentLoaded", function () {
  const element = document.querySelector(".carousel-items");
  const leftArrow = document.querySelector(".carousel-left-arrow > i");
  const rightArrow = document.querySelector(".carousel-right-arrow > i");
  const carouselItems = Array.from(document.querySelectorAll(".carousel-item"));
  const carouselGroups = [];

  let step = Number(
    document.querySelector(".carousel-script").getAttribute("step")
  );
  let lastPage = step - (carouselItems.length % step);
  let currentSlice = 0;
  let range = 0;
  let currentRender = 0;

  function leftClick() {
    if (rightArrow.classList.contains("disabled")) {
      rightArrow.classList.remove("disabled");
    }

    if (currentRender !== 0) {
      element.innerHTML = "";
      currentRender -= 1;
      element.innerHTML = carouselGroups[currentRender]
        .map((image) => image.outerHTML)
        .toString()
        .replaceAll(",", "");
    }

    if (currentRender === 0) {
      leftArrow.classList.add("disabled");
    }
  }

  function rightClick() {
    if (leftArrow.classList.contains("disabled")) {
      leftArrow.classList.remove("disabled");
    }

    if (currentRender < carouselGroups.length - 1) {
      element.innerHTML = "";
      currentRender += 1;
      element.innerHTML = carouselGroups[currentRender]
        .map((image) => image.outerHTML)
        .toString()
        .replaceAll(",", "");
    }

    if (currentRender === carouselGroups.length - 1) {
      rightArrow.classList.add("disabled");
    }
  }

  leftArrow.onclick = () => leftClick();
  rightArrow.onclick = () => rightClick();

  while (currentSlice < carouselItems.length) {
    const tempList = [];

    if (window.innerWidth <= 430 && step !== 1) {
      step = 2;
      element.querySelectorAll(".carousel-item").forEach((item) => {
        item.style.width = "22vw";
      });

      element.style.justifyContent = "space-around";
    }

    if (step === 5) {
      element.querySelectorAll(".carousel-item").forEach((item) => {
        item.style.width = "10%";
      });
    } else if (step === 1) {
      element.style.justifyContent = "center";
    }

    if (currentSlice + step > carouselItems.length) {
      range = lastPage;
    }

    for (let i = currentSlice; i < currentSlice + step - range; i++) {
      tempList.push(carouselItems[i]);
    }

    carouselGroups.push(tempList);
    currentSlice += step;
  }

  if (currentRender === 0) {
    leftArrow.classList.add("disabled");
  }

  element.innerHTML = carouselGroups[currentRender]
    .map((image) => image.outerHTML)
    .toString()
    .replaceAll(",", "");
});
