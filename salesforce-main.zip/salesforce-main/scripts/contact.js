const faqs = document.getElementsByClassName("faq-title-wrapper");

for (let i = 0; i < faqs.length; i++) {
  faqs[i].addEventListener("click", function () {
    this.classList.toggle("active");
    let hidden = this.nextElementSibling;
    if (hidden.style.maxHeight) {
      hidden.style.maxHeight = null;
    } else {
      hidden.style.maxHeight = hidden.scrollHeight + "px";
    }
  });
}
